# MediaGrab — Android video / ses / altyazı indirici

Motor: yt-dlp + ffmpeg (YouTube ve 1000'den fazla site). Tamamen ücretsiz, açık kaynak kütüphanelerle.

## Özellikler
- Video: çözünürlük (144p → 4K) ve biçim (mp4 / mkv / webm)
- Ses: mp3, m4a, opus, flac, wav, aac, vorbis + bitrate seçimi
- Altyazı: sadece altyazı ya da videoyla birlikte; dil seçimi, otomatik altyazı, srt/vtt/ass, videoya gömme
- Oynatma listesi, etiket (metadata) gömme, paralel indirme, ilerleme çubuğu, iptal
- YouTube uygulamasından Paylaş → MediaGrab
- Uygulama içinden yt-dlp güncelleme (YouTube değişince ilk yapılacak şey)
- Gelişmiş kutusu: istediğin yt-dlp parametresini elle ekle (ör. `--limit-rate 2M`)
- Dosyalar: İndirilenler/MediaGrab

## APK nasıl alınır
**Yol A — Android Studio:** klasörü aç → Build → Build APK(s) →
`app/build/outputs/apk/debug/app-debug.apk`

**Yol B — bilgisayarsız, GitHub ile:** ücretsiz GitHub hesabı → yeni repo → bu klasörün içeriğini yükle →
Actions sekmesi → "APK derle" → bitince "Artifacts" altından `MediaGrab-apk` indir.

Telefonda APK'yı açarken "bilinmeyen kaynaklardan yükle" iznini ver.

## Nerede ne değiştirilir
| İstek | Dosya |
|---|---|
| Kalite/biçim listeleri | `MainActivity.kt` en üstteki listeler |
| yt-dlp parametreleri | `MainActivity.kt` → `buildRequest()` |
| Arayüz | `res/layout/activity_main.xml` |
| Kayıt klasörü | `MainActivity.kt` → `saveToDownloads()` |
| 32-bit cihaz desteği | `app/build.gradle.kts` → `abiFilters` |
| Uygulama adı | `res/values/strings.xml` |

## Eklenebilecekler (yol haritası)
Arka plan servisi + bildirimde ilerleme, indirme kuyruğu/geçmiş (Room), kapak resmi önizleme (Coil),
giriş gerektiren videolar için çerez desteği, SponsorBlock, bölüm bölüm ayırma, aria2c ile hızlandırma.

## Not
Başkalarının telif hakkıyla korunan içeriğini indirmek ve YouTube Hizmet Şartları sizin sorumluluğunuzdadır;
kişisel/yasal kullanım için kullanın. Uygulama Play Store kurallarına uymaz, APK olarak dağıtılır.
