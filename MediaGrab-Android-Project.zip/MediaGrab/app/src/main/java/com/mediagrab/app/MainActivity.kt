package com.mediagrab.app

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.mediagrab.app.databinding.ActivityMainBinding
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    // ───────── Seçenek listeleri: ekle / çıkar, arayüz kendiliğinden güncellenir ─────────
    private val videoQualities = listOf(
        "En iyi" to 0, "2160p (4K)" to 2160, "1440p" to 1440, "1080p" to 1080,
        "720p" to 720, "480p" to 480, "360p" to 360, "240p" to 240, "144p" to 144
    )
    private val containers = listOf("mp4", "mkv", "webm")
    private val audioFormats = listOf("mp3", "m4a", "opus", "flac", "wav", "aac", "vorbis")
    private val audioQualities = listOf(
        "En iyi" to "0", "320 kbps" to "320K", "256 kbps" to "256K",
        "192 kbps" to "192K", "128 kbps" to "128K", "96 kbps" to "96K", "64 kbps" to "64K"
    )
    private val subFormats = listOf("srt", "vtt", "ass")
    // ────────────────────────────────────────────────────────────────────────────────

    private enum class Mode { VIDEO, AUDIO, SUBS }

    private lateinit var b: ActivityMainBinding
    private val processId = "mediagrab-download"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        fill(b.spVideoQuality, videoQualities.map { it.first })
        fill(b.spContainer, containers)
        fill(b.spAudioFormat, audioFormats)
        fill(b.spAudioQuality, audioQualities.map { it.first })
        fill(b.spSubFormat, subFormats)

        b.rgMode.setOnCheckedChangeListener { _, _ -> updateModeUi() }
        b.btnInfo.setOnClickListener { fetchInfo() }
        b.btnDownload.setOnClickListener { startDownload() }
        b.btnCancel.setOnClickListener { YoutubeDL.getInstance().destroyProcessById(processId) }
        b.btnUpdate.setOnClickListener { updateEngine() }

        updateModeUi()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** YouTube'dan "Paylaş > MediaGrab" ile gelen bağlantıyı al. */
    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            b.etUrl.setText(Regex("https?://\\S+").find(text)?.value ?: text)
        }
    }

    private fun fill(s: Spinner, items: List<String>) {
        s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
    }

    private fun mode() = when (b.rgMode.checkedRadioButtonId) {
        b.rbAudio.id -> Mode.AUDIO
        b.rbSubs.id -> Mode.SUBS
        else -> Mode.VIDEO
    }

    private fun updateModeUi() {
        val m = mode()
        b.grpVideo.visibility = if (m == Mode.VIDEO) View.VISIBLE else View.GONE
        b.grpAudio.visibility = if (m == Mode.AUDIO) View.VISIBLE else View.GONE
        b.grpSubs.visibility = if (m == Mode.AUDIO) View.GONE else View.VISIBLE
        if (m == Mode.SUBS) b.cbSubs.isChecked = true
        b.cbSubs.isEnabled = m != Mode.SUBS
        b.cbEmbed.isEnabled = m == Mode.VIDEO
    }

    // ───────── Bilgi getir ─────────
    private fun fetchInfo() {
        val url = b.etUrl.text.toString().trim()
        if (url.isEmpty()) return toast("Önce bir bağlantı yapıştır")
        lifecycleScope.launch {
            status("Bilgi alınıyor…")
            try {
                val info = withContext(Dispatchers.IO) { YoutubeDL.getInstance().getInfo(url) }
                val d = info.duration
                b.tvTitle.text = info.title
                b.tvMeta.text = "${info.uploader} • %d:%02d".format(d / 60, d % 60)
                status("Hazır")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status("Hata: ${e.message}")
            }
        }
    }

    // ───────── İndir ─────────
    private fun buildRequest(url: String, out: File): YoutubeDLRequest {
        val m = mode()
        val r = YoutubeDLRequest(url)
        r.addOption("-o", "${out.absolutePath}/%(title).120B [%(id)s].%(ext)s")
        r.addOption("-N", "4")                       // paralel parça indirme (hız)
        r.addOption("--no-mtime")
        if (!b.cbPlaylist.isChecked) r.addOption("--no-playlist")
        if (b.cbMeta.isChecked && m != Mode.SUBS) r.addOption("--embed-metadata")

        when (m) {
            Mode.VIDEO -> {
                val h = videoQualities[b.spVideoQuality.selectedItemPosition].second
                val box = containers[b.spContainer.selectedItemPosition]
                val hf = if (h > 0) "[height<=$h]" else ""
                // mp4 için önce uyumlu H.264+AAC dene, yoksa en iyisine düş
                val f = if (box == "mp4")
                    "bv*$hf[ext=mp4]+ba[ext=m4a]/b$hf[ext=mp4]/bv*$hf+ba/b$hf"
                else "bv*$hf+ba/b$hf"
                r.addOption("-f", f)
                r.addOption("--merge-output-format", box)
            }
            Mode.AUDIO -> {
                r.addOption("-f", "ba/b")
                r.addOption("-x")
                r.addOption("--audio-format", audioFormats[b.spAudioFormat.selectedItemPosition])
                r.addOption("--audio-quality", audioQualities[b.spAudioQuality.selectedItemPosition].second)
            }
            Mode.SUBS -> r.addOption("--skip-download")
        }

        if (m != Mode.AUDIO && b.cbSubs.isChecked) {
            r.addOption("--write-subs")
            if (b.cbAuto.isChecked) r.addOption("--write-auto-subs")
            r.addOption("--sub-langs", b.etLangs.text.toString().trim().ifEmpty { "tr,en" })
            r.addOption("--convert-subs", subFormats[b.spSubFormat.selectedItemPosition])
            if (m == Mode.VIDEO && b.cbEmbed.isChecked) r.addOption("--embed-subs")
        }

        // Gelişmiş: kullanıcının elle yazdığı ek yt-dlp parametreleri
        b.etExtra.text.toString().trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
            .forEach { r.addOption(it) }
        return r
    }

    private fun startDownload() {
        val url = b.etUrl.text.toString().trim()
        if (url.isEmpty()) return toast("Önce bir bağlantı yapıştır")

        val tmp = File(getExternalFilesDir(null), "tmp").apply { deleteRecursively(); mkdirs() }
        val request = buildRequest(url, tmp)
        setBusy(true)
        b.tvLog.text = ""

        lifecycleScope.launch {
            try {
                val saved = withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().execute(request, processId) { progress, eta, line ->
                        runOnUiThread {
                            b.progress.progress = progress.coerceAtLeast(0f).toInt()
                            b.tvStatus.text = "%.1f%%  •  kalan ${eta} sn".format(progress.coerceAtLeast(0f))
                            appendLog(line)
                        }
                    }
                    val files = tmp.listFiles().orEmpty().filter {
                        it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl")
                    }
                    files.forEach { saveToDownloads(it) }
                    files.size
                }
                b.progress.progress = 100
                status("✅ Bitti: $saved dosya  →  İndirilenler/MediaGrab")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status("❌ Durdu: ${e.message?.take(300)}")
            } finally {
                setBusy(false)
            }
        }
    }

    /** İndirilen dosyayı herkese açık İndirilenler/MediaGrab klasörüne taşır. */
    private fun saveToDownloads(f: File) {
        val mime = MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(f.extension.lowercase()) ?: "application/octet-stream"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, f.name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/MediaGrab")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Dosya kaydedilemedi: ${f.name}")
        contentResolver.openOutputStream(uri)!!.use { out ->
            f.inputStream().use { it.copyTo(out) }
        }
        f.delete()
    }

    // ───────── yt-dlp güncelle (YouTube sık değişir, bu önemli) ─────────
    private fun updateEngine() {
        lifecycleScope.launch {
            status("Motor güncelleniyor…")
            try {
                val r = withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().updateYoutubeDL(applicationContext, YoutubeDL.UpdateChannel.STABLE)
                }
                status("Güncelleme sonucu: $r")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status("Güncellenemedi: ${e.message}")
            }
        }
    }

    // ───────── Yardımcılar ─────────
    private fun setBusy(busy: Boolean) {
        b.btnDownload.isEnabled = !busy
        b.btnInfo.isEnabled = !busy
        b.btnUpdate.isEnabled = !busy
        b.btnCancel.isEnabled = busy
        if (busy) b.progress.progress = 0
    }

    private fun appendLog(line: String?) {
        val l = line?.trim().orEmpty()
        if (l.isNotEmpty()) b.tvLog.text = (b.tvLog.text.toString() + l + "\n").takeLast(4000)
    }

    private fun status(s: String) { b.tvStatus.text = s }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
