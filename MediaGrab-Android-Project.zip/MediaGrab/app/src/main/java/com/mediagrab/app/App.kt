package com.mediagrab.app

import android.app.Application
import android.util.Log
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLException

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            // İlk açılışta motor dosyaları çıkarılır; birkaç saniye sürebilir.
            YoutubeDL.getInstance().init(this)
            FFmpeg.getInstance().init(this)
        } catch (e: YoutubeDLException) {
            Log.e("MediaGrab", "Motor başlatılamadı", e)
        }
    }
}
