plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mediagrab.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mediagrab.app"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // Çoğu modern telefon arm64'tür. Eski 32-bit cihazlar için "armeabi-v7a" ekle
        // (APK boyutu büyür).
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    buildFeatures { viewBinding = true }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // yt-dlp / python / ffmpeg yerel kütüphaneleri için gerekli
    packaging { jniLibs { useLegacyPackaging = true } }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // yt-dlp + ffmpeg motoru (YouTube ve 1000+ site)
    val ytdl = "0.17.4"
    implementation("io.github.junkfood02.youtubedl-android:library:$ytdl")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:$ytdl")
}
